"""
:mod:`region` -- Regionalization
================================

"""

from maxp import *
from randomregion import *
from components import *
