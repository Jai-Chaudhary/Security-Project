"""
:mod:`inequality` --- Spatial Inequality Analysis
=================================================

"""

import theil
import gini
